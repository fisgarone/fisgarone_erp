// ===== API INTEGRATION SERVICE =====
class APIIntegration {
    constructor() {
        this.baseURL = 'http://localhost:5000/api';
        this.cache = new Map();
        this.cacheTimeout = 30000; // 30 segundos
        this.retryAttempts = 3;
        this.retryDelay = 1000;
    }

    // ===== BUSCAR DADOS DO DASHBOARD =====
    async fetchDashboardData() {
        const cacheKey = 'dashboard_data';
        const cached = this.getCachedData(cacheKey);

        if (cached) {
            console.log('📦 Retornando dados em cache');
            return cached;
        }

        try {
            console.log('🔗 Conectando com API...');

            const endpoints = [
                '/ml/analytics/overview',
                '/ml/analytics/trends',
                '/ml/analytics/abc',
                '/ml/analytics/top-items',
                '/ml/sync/status'
            ];

            const requests = endpoints.map(endpoint =>
                this.retryableFetch(`${this.baseURL}${endpoint}`)
                    .then(response => {
                        if (!response.ok) throw new Error(`HTTP ${response.status}`);
                        return response.json();
                    })
                    .catch(error => {
                        console.warn(`⚠️ Endpoint ${endpoint} falhou:`, error);
                        return this.getMockEndpointData(endpoint);
                    })
            );

            const results = await Promise.all(requests);

            const dashboardData = {
                overview: results[0],
                trends: results[1],
                abc: results[2],
                topItems: results[3],
                syncStatus: results[4],
                timestamp: new Date().toISOString()
            };

            // Cache dos dados
            this.setCachedData(cacheKey, dashboardData);

            console.log('✅ Dados do dashboard carregados com sucesso');
            return dashboardData;

        } catch (error) {
            console.error('❌ Erro crítico na API:', error);
            return this.getMockData();
        }
    }

    // ===== FETCH COM RETRY =====
    async retryableFetch(url, options = {}, attempt = 1) {
        try {
            const response = await fetch(url, {
                ...options,
                timeout: 10000 // 10 segundos timeout
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            return response;
        } catch (error) {
            if (attempt < this.retryAttempts) {
                console.warn(`🔄 Tentativa ${attempt} falhou, tentando novamente...`);
                await this.delay(this.retryDelay * attempt);
                return this.retryableFetch(url, options, attempt + 1);
            }
            throw error;
        }
    }

    // ===== DADOS MOCK PARA DEMONSTRAÇÃO =====
    getMockEndpointData(endpoint) {
        const mockData = {
            '/ml/analytics/overview': {
                success: true,
                data: {
                    kpis: [
                        {name: 'Total de Vendas', value: 38, unit: 'vendas'},
                        {name: 'Faturamento Bruto', value: 2522.73, unit: 'R$'},
                        {name: 'Faturamento Líquido', value: 2144.32, unit: 'R$'},
                        {name: 'Ticket Médio', value: 74.20, unit: 'R$'},
                        {name: 'Lucro Estimado', value: 643.30, unit: 'R$'}
                    ],
                    last_updated: new Date().toISOString()
                }
            },
            '/ml/analytics/trends': {
                success: true,
                data: {
                    daily_data: [
                        {date: '2025-10-21', total_sales: 769.26},
                        {date: '2025-10-22', total_sales: 310.48},
                        {date: '2025-10-23', total_sales: 115.75},
                        {date: '2025-10-24', total_sales: 452.90},
                        {date: '2025-10-25', total_sales: 289.35},
                        {date: '2025-10-26', total_sales: 586.15},
                        {date: '2025-10-27', total_sales: 423.80}
                    ],
                    period: '7d'
                }
            },
            '/ml/analytics/abc': {
                success: true,
                data: {
                    items: [
                        {title: 'Kit Festa 200 Lembrancinha', total_sales: 375.18, classification: 'A'},
                        {title: 'Kit Sacolinha Aniversario', total_sales: 245.85, classification: 'A'},
                        {title: 'Kit Lembrancinha Surpresa', total_sales: 170.61, classification: 'B'},
                        {title: 'Brinquedo Educativo', total_sales: 154.10, classification: 'B'},
                        {title: 'Kit Festa Infantil', total_sales: 142.35, classification: 'B'},
                        {title: 'Lembrancinha Personalizada', total_sales: 98.75, classification: 'C'},
                        {title: 'Brinquedo Montessoriano', total_sales: 87.45, classification: 'C'},
                        {title: 'Kit Aniversário Kids', total_sales: 76.30, classification: 'C'}
                    ],
                    summary: {
                        class_a_count: 2,
                        class_b_count: 3,
                        class_c_count: 3
                    }
                }
            },
            '/ml/analytics/top-items': {
                success: true,
                data: {
                    items: [
                        {title: 'Kit Festa 200 Lembrancinha', total_sales: 375.18, total_profit: 112.55},
                        {title: 'Kit Sacolinha Aniversario', total_sales: 245.85, total_profit: 73.76},
                        {title: 'Kit Lembrancinha Surpresa', total_sales: 170.61, total_profit: 51.18}
                    ],
                    period: 'all_time'
                }
            },
            '/ml/sync/status': {
                success: true,
                data: {
                    total_vendas: 38,
                    status: 'sincronizado',
                    last_sync: new Date().toISOString(),
                    next_sync: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutos
                }
            }
        };

        return mockData[endpoint] || {success: false, data: null, error: 'Endpoint não encontrado'};
    }

    getMockData() {
        console.log('🔄 Usando dados mock completos...');
        return {
            overview: this.getMockEndpointData('/ml/analytics/overview'),
            trends: this.getMockEndpointData('/ml/analytics/trends'),
            abc: this.getMockEndpointData('/ml/analytics/abc'),
            topItems: this.getMockEndpointData('/ml/analytics/top-items'),
            syncStatus: this.getMockEndpointData('/ml/sync/status'),
            timestamp: new Date().toISOString(),
            source: 'mock'
        };
    }

    // ===== SISTEMA DE CACHE =====
    getCachedData(key) {
        const cached = this.cache.get(key);
        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            return cached.data;
        }
        this.cache.delete(key);
        return null;
    }

    setCachedData(key, data) {
        this.cache.set(key, {
            data: data,
            timestamp: Date.now()
        });
    }

    clearCache() {
        this.cache.clear();
        console.log('🧹 Cache limpo');
    }

    // ===== TESTAR CONEXÃO =====
    async testConnection() {
        try {
            const startTime = Date.now();
            const response = await this.retryableFetch(`${this.baseURL}/status`);
            const endTime = Date.now();

            const data = await response.json();

            return {
                connected: true,
                data: data,
                responseTime: endTime - startTime,
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            return {
                connected: false,
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    // ===== SINCRONIZAR DADOS MANUALMENTE =====
    async syncData(companyId = 1) {
        try {
            console.log(`🔄 Iniciando sincronização para empresa ${companyId}...`);

            const response = await this.retryableFetch(`${this.baseURL}/ml/sync/${companyId}`, {
                method: 'POST'
            });

            const result = await response.json();

            // Limpar cache após sincronização
            this.clearCache();

            console.log('✅ Sincronização concluída:', result);
            return result;

        } catch (error) {
            console.error('❌ Erro na sincronização:', error);
            throw error;
        }
    }

    // ===== BUSCAR DADOS COM FILTROS =====
    async fetchFilteredData(filters = {}) {
        try {
            const queryParams = new URLSearchParams();

            // Adicionar filtros aos parâmetros
            Object.entries(filters).forEach(([key, value]) => {
                if (value && value !== 'all') {
                    queryParams.append(key, value);
                }
            });

            const url = `${this.baseURL}/ml/analytics/filtered?${queryParams.toString()}`;
            const response = await this.retryableFetch(url);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();
            console.log('✅ Dados filtrados carregados:', filters);
            return data;

        } catch (error) {
            console.warn('⚠️ Fallback para dados mock filtrados:', error);
            return this.getMockFilteredData(filters);
        }
    }

    // ===== DADOS MOCK FILTRADOS =====
    getMockFilteredData(filters) {
        // Simular efeito dos filtros nos dados mock
        const baseData = this.getMockData();

        // Aplicar "filtros" nos dados mock
        if (filters.period && filters.period !== '7d') {
            // Simular diferentes períodos
            baseData.trends.data.daily_data = baseData.trends.data.daily_data.slice(0, 3);
        }

        if (filters.category && filters.category !== 'all') {
            // Simular filtro de categoria
            baseData.abc.data.items = baseData.abc.data.items.filter(
                item => item.classification === filters.category
            );
        }

        baseData.filters = filters;
        baseData.timestamp = new Date().toISOString();

        return baseData;
    }

    // ===== UTILITÁRIOS =====
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ===== OBTER ESTATÍSTICAS DE USO =====
    getUsageStats() {
        return {
            cacheSize: this.cache.size,
            cacheHits: Array.from(this.cache.values()).filter(item =>
                Date.now() - item.timestamp < this.cacheTimeout
            ).length,
            baseURL: this.baseURL,
            retryAttempts: this.retryAttempts
        };
    }

    // ===== ATUALIZAR CONFIGURAÇÃO =====
    updateConfig(newConfig) {
        if (newConfig.baseURL) {
            this.baseURL = newConfig.baseURL;
        }
        if (newConfig.retryAttempts) {
            this.retryAttempts = newConfig.retryAttempts;
        }
        if (newConfig.cacheTimeout) {
            this.cacheTimeout = newConfig.cacheTimeout;
        }

        console.log('⚙️ Configuração da API atualizada:', newConfig);
    }

    // ===== DESTRUIDOR =====
    destroy() {
        this.clearCache();
        console.log('🧹 API Integration destruído');
    }
}

// Instância global
window.apiIntegration = new APIIntegration();